import React, { useState, useEffect, useMemo } from 'react';
import Card from './ui/Card';
import { ruleCategories } from '../data/rules';
import ToggleSwitch from './ui/ToggleSwitch';
import { getRuleSettings, saveRuleSettings, resetRuleSettings } from '../services/apiService';
import Spinner from './ui/Spinner';

const RuleEngineView: React.FC = () => {
    const [ruleStates, setRuleStates] = useState<Record<string, boolean> | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [toast, setToast] = useState<{ message: string; visible: boolean }>({ message: '', visible: false });

    useEffect(() => {
        const fetchSettings = async () => {
            try {
                setLoading(true);
                const settings = await getRuleSettings();
                setRuleStates(settings);
            } catch (err) {
                setError('Не удалось загрузить настройки правил.');
                console.error(err);
            } finally {
                setLoading(false);
            }
        };
        fetchSettings();
    }, []);

    useEffect(() => {
        if (toast.visible) {
            const timer = setTimeout(() => setToast({ ...toast, visible: false }), 3000);
            return () => clearTimeout(timer);
        }
    }, [toast]);
    
    const showToast = (message: string) => {
        setToast({ message, visible: true });
    };

    const handleToggle = (ruleId: string) => {
        if (!ruleStates) return;
        setRuleStates(prev => ({ ...prev!, [ruleId]: !prev![ruleId] }));
    };

    const handleSave = async () => {
        if (!ruleStates) return;
        try {
            await saveRuleSettings(ruleStates);
            showToast('Настройки правил сохранены!');
        } catch (error) {
            console.error("Error saving settings", error);
            showToast('Ошибка сохранения настроек.');
        }
    };
    
    const handleReset = async () => {
        try {
            const defaultState = await resetRuleSettings();
            setRuleStates(defaultState);
            showToast('Настройки сброшены по умолчанию.');
        } catch(error) {
            console.error("Error resetting settings", error);
            showToast('Ошибка сброса настроек.');
        }
    };

    const { enabledCount, totalCount } = useMemo(() => {
        if (!ruleStates) return { enabledCount: 0, totalCount: 0 };
        const enabled = Object.values(ruleStates).filter(Boolean).length;
        const total = Object.values(ruleStates).length;
        return { enabledCount: enabled, totalCount: total };
    }, [ruleStates]);
    
     if (loading) {
        return <div className="flex justify-center items-center h-full"><Spinner size="h-16 w-16" /></div>;
    }
    
    if (error || !ruleStates) {
        return <div className="text-center text-critical p-4 bg-red-100 rounded-lg">{error || 'Произошла ошибка.'}</div>;
    }
    
    return (
        <div className="space-y-6 max-w-7xl mx-auto">
            {/* Header */}
            <div className="md:flex md:items-center md:justify-between">
                <div className="flex-1 min-w-0">
                    <h1 className="text-3xl font-bold text-text-primary dark:text-dark-text-primary">Правила и Контроль</h1>
                    <p className="mt-1 text-text-secondary dark:text-dark-text-secondary">
                        Управляйте правилами для выявления ошибок, аномалий и мошенничества в документах.
                    </p>
                </div>
                <div className="mt-4 flex md:mt-0 md:ml-4 space-x-2">
                    <button
                        onClick={handleReset}
                        className="bg-surface dark:bg-dark-surface px-4 py-2 text-sm font-medium text-text-primary dark:text-dark-text-primary border border-border dark:border-dark-border rounded-lg shadow-sm hover:bg-gray-50 dark:hover:bg-dark-surface/50"
                    >
                        Сбросить
                    </button>
                    <button
                        onClick={handleSave}
                        className="bg-primary dark:bg-dark-primary px-4 py-2 text-sm font-medium text-white rounded-lg shadow-sm hover:bg-primary-hover dark:hover:bg-dark-primary-hover"
                    >
                        Сохранить изменения
                    </button>
                </div>
            </div>

            {/* Stats */}
            <Card className="!p-4">
                <p className="text-center font-medium text-text-secondary dark:text-dark-text-secondary">
                    <span className="font-bold text-primary dark:text-dark-primary">{enabledCount}</span> из {totalCount} правил включено
                </p>
            </Card>

            {/* Rule Categories */}
            <div className="space-y-6">
                {ruleCategories.map(category => (
                    <Card key={category.title}>
                        <h2 className="text-xl font-semibold mb-4 text-text-primary dark:text-dark-text-primary">{category.title}</h2>
                        <div className="divide-y divide-border/50 dark:divide-dark-border/50">
                            {category.rules.map(rule => (
                                <div key={rule.id} className="flex items-center justify-between py-4 transition-colors hover:bg-gray-50 dark:hover:bg-dark-surface/30 -mx-6 px-6">
                                    <div className="flex-1 pr-4">
                                        <p className="font-medium text-text-primary dark:text-dark-text-primary">
                                            <span className="font-mono text-xs bg-gray-100 dark:bg-dark-background text-text-secondary dark:text-dark-text-secondary py-0.5 px-1.5 rounded-md mr-2">{rule.id}</span>
                                            {rule.description}
                                        </p>
                                        <p className="text-sm text-text-secondary dark:text-dark-text-secondary mt-1 italic">Пример: {rule.example}</p>
                                    </div>
                                    <ToggleSwitch enabled={ruleStates[rule.id] ?? false} onChange={() => handleToggle(rule.id)} />
                                </div>
                            ))}
                        </div>
                    </Card>
                ))}
            </div>

            {/* Toast Notification */}
            <div
                aria-live="assertive"
                className={`fixed inset-0 flex items-end justify-center px-4 py-6 pointer-events-none sm:p-6 sm:items-start transition-opacity duration-300 ${toast.visible ? 'opacity-100' : 'opacity-0'}`}
            >
                <div className="w-full flex flex-col items-center space-y-4 sm:items-end">
                    <div className="max-w-sm w-full bg-surface dark:bg-dark-surface shadow-lg rounded-lg pointer-events-auto ring-1 ring-black ring-opacity-5 overflow-hidden">
                        <div className="p-4">
                            <div className="flex items-center">
                                <div className="ml-3 w-0 flex-1 pt-0.5">
                                    <p className="text-sm font-medium text-text-primary dark:text-dark-text-primary">{toast.message}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default RuleEngineView;