import React, { useState, useEffect } from 'react';
import { Anomaly, Severity, Category, Status } from '../types';
import Card from './ui/Card';
import Spinner from './ui/Spinner';
import Badge from './ui/Badge';
import { getDashboardData } from '../services/apiService';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend } from 'recharts';

const COLORS = {
  [Category.Fraud]: '#DC2626',
  [Category.Error]: '#F97316',
  [Category.PolicyViolation]: '#F59E0B',
  [Category.UnusualActivity]: '#2563EB',
};

const SEVERITY_COLORS = {
    [Severity.Critical]: '#DC2626',
    [Severity.High]: '#F97316',
    [Severity.Medium]: '#F59E0B',
    [Severity.Low]: '#16A34A',
}

interface DashboardState {
    stats: {
        totalAnomalies: number;
        criticalCount: number;
        highRiskCount: number;
        inReviewCount: number;
    };
    chartData: {
        categoryData: {name: string, value: number}[];
        severityData: {name: string, value: number}[];
    };
    recentHighRiskAnomalies: Anomaly[];
}

const DashboardView: React.FC = () => {
  const [data, setData] = useState<DashboardState | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
        try {
            setLoading(true);
            const dashboardData = await getDashboardData();
            setData(dashboardData);
        } catch (err) {
            setError("Не удалось загрузить данные для панели управления.");
            console.error(err);
        } finally {
            setLoading(false);
        }
    };
    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full">
        <Spinner size="h-16 w-16" />
      </div>
    );
  }
  
  if (error || !data) {
     return <div className="text-center text-critical p-4 bg-red-100 rounded-lg">{error || 'Произошла ошибка.'}</div>;
  }
  
  const { stats, chartData, recentHighRiskAnomalies } = data;

  const StatCard: React.FC<{title: string, value: number, colorClass: string}> = ({ title, value, colorClass }) => (
    <Card>
      <h3 className="text-text-secondary dark:text-dark-text-secondary font-medium text-sm">{title}</h3>
      <p className={`text-4xl font-bold ${colorClass}`}>{value}</p>
    </Card>
  );
  
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="p-2 bg-surface dark:bg-dark-surface border border-border dark:border-dark-border rounded-md shadow-lg">
          <p className="label text-text-primary dark:text-dark-text-primary">{`${label} : ${payload[0].value}`}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-text-primary dark:text-dark-text-primary">Панель управления</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Всего аномалий" value={stats.totalAnomalies} colorClass="text-primary dark:text-dark-primary" />
        <StatCard title="Критических" value={stats.criticalCount} colorClass="text-critical" />
        <StatCard title="Высокий риск" value={stats.highRiskCount} colorClass="text-high" />
        <StatCard title="В обработке" value={stats.inReviewCount} colorClass="text-purple-600 dark:text-purple-400" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <Card className="lg:col-span-3">
          <h3 className="text-xl font-semibold mb-4 text-text-primary dark:text-dark-text-primary">Аномалии по критичности</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={chartData.severityData} margin={{ top: 5, right: 20, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" className="dark:stroke-dark-border" />
                <XAxis dataKey="name" stroke="#6B7280" className="dark:stroke-dark-text-secondary" fontSize={12} tick={{ fill: 'currentColor' }} />
                <YAxis stroke="#6B7280" className="dark:stroke-dark-text-secondary" fontSize={12} tick={{ fill: 'currentColor' }} />
                <Tooltip cursor={{fill: 'rgba(128,128,128,0.1)'}} content={<CustomTooltip />} />
                <Bar dataKey="value" barSize={40}>
                    {chartData.severityData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={SEVERITY_COLORS[entry.name as Severity]} />
                    ))}
                </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="lg:col-span-2">
            <h3 className="text-xl font-semibold mb-4 text-text-primary dark:text-dark-text-primary">Аномалии по категориям</h3>
            <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                    <Pie data={chartData.categoryData} cx="50%" cy="50%" labelLine={false} outerRadius={110} fill="#8884d8" dataKey="value" nameKey="name" label={({ name, percent }) => `${(percent * 100).toFixed(0)}%`}>
                        {chartData.categoryData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[entry.name as Category]} stroke={document.documentElement.classList.contains('dark') ? '#1F2937' : '#FFFFFF'} />
                        ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip />} />
                    <Legend iconType="circle" wrapperStyle={{fontSize: '12px'}}/>
                </PieChart>
            </ResponsiveContainer>
        </Card>
      </div>

      <Card>
        <h3 className="text-xl font-semibold mb-4 text-text-primary dark:text-dark-text-primary">Недавние аномалии высокого риска</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-border dark:border-dark-border">
                <th className="p-3 font-semibold text-sm text-text-secondary dark:text-dark-text-secondary">ID</th>
                <th className="p-3 font-semibold text-sm text-text-secondary dark:text-dark-text-secondary">Описание</th>
                <th className="p-3 font-semibold text-sm text-text-secondary dark:text-dark-text-secondary">Критичность</th>
                <th className="p-3 font-semibold text-sm text-text-secondary dark:text-dark-text-secondary">Статус</th>
              </tr>
            </thead>
            <tbody>
              {recentHighRiskAnomalies.map((anomaly) => (
                <tr key={anomaly.id} className="border-b border-border/50 dark:border-dark-border/50 hover:bg-gray-50 dark:hover:bg-dark-surface/50">
                  <td className="p-4 font-mono text-sm text-primary dark:text-dark-primary font-medium">{anomaly.id}</td>
                  <td className="p-4 text-sm text-text-primary dark:text-dark-text-primary">{anomaly.description}</td>
                  <td className="p-4"><Badge type={anomaly.severity} /></td>
                  <td className="p-4"><Badge type={anomaly.status} /></td>
                </tr>
              ))}
               {recentHighRiskAnomalies.length === 0 && (
                  <tr>
                      <td colSpan={4} className="text-center p-8 text-text-secondary dark:text-dark-text-secondary">Нет аномалий высокого риска.</td>
                  </tr>
                )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

export default DashboardView;