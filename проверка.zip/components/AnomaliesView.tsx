import React, { useState, useEffect, useCallback } from 'react';
import { Anomaly, Severity, Status } from '../types';
import { getAnomalies, updateAnomaly } from '../services/apiService';
import Card from './ui/Card';
import Spinner from './ui/Spinner';
import Badge from './ui/Badge';
import { ArrowLeftIcon, UserCircleIcon } from './ui/icons';

const AnomalyDetail: React.FC<{ 
    anomaly: Anomaly, 
    onBack: () => void,
    onSave: (updatedAnomaly: Anomaly) => Promise<void>
}> = ({ anomaly: initialAnomaly, onBack, onSave }) => {
    const [anomaly, setAnomaly] = useState<Anomaly>(initialAnomaly);
    const [isSaving, setIsSaving] = useState(false);

    const handleStatusChange = (newStatus: Status) => {
        setAnomaly(prev => ({ ...prev, status: newStatus }));
    };

    const handleAssigneeChange = (newAssignee: string) => {
        setAnomaly(prev => ({...prev, assignee: newAssignee}));
    };
    
    const handleSaveAndReturn = async () => {
        setIsSaving(true);
        try {
            await onSave(anomaly);
            onBack();
        } catch (error) {
            console.error("Failed to save anomaly:", error);
            // Optionally show an error to the user
        } finally {
            setIsSaving(false);
        }
    }

    return (
        <div className="space-y-6 max-w-4xl mx-auto">
            <button onClick={onBack} className="flex items-center text-sm text-primary dark:text-dark-primary font-semibold hover:underline">
                <ArrowLeftIcon className="w-5 h-5 mr-1" />
                Назад к списку
            </button>
            
            <Card>
                <h2 className="text-2xl font-bold text-text-primary dark:text-dark-text-primary">{anomaly.category} - {anomaly.id}</h2>
                <p className="text-text-secondary dark:text-dark-text-secondary mt-1">{anomaly.description}</p>
            </Card>

            <Card>
                <h3 className="text-lg font-semibold mb-4 border-b border-border dark:border-dark-border pb-3 text-text-primary dark:text-dark-text-primary">Детали инцидента</h3>
                <div className="space-y-4 text-sm">
                    <div>
                        <label className="block text-xs text-text-secondary dark:text-dark-text-secondary mb-1">Критичность</label>
                        <Badge type={anomaly.severity} />
                    </div>
                    <div>
                        <label className="block text-xs text-text-secondary dark:text-dark-text-secondary mb-1">Дата</label>
                        <p className="font-semibold text-text-primary dark:text-dark-text-primary">{new Date(anomaly.date).toLocaleDateString('ru-RU')}</p>
                    </div>
                    <div>
                        <label htmlFor="status-select" className="block text-xs text-text-secondary dark:text-dark-text-secondary mb-1">Статус</label>
                        <select 
                            id="status-select" 
                            value={anomaly.status} 
                            onChange={(e) => handleStatusChange(e.target.value as Status)}
                            className="w-full p-2 bg-surface dark:bg-dark-surface border border-border dark:border-dark-border rounded-md shadow-sm focus:ring-primary dark:focus:ring-dark-primary focus:border-primary dark:focus:border-dark-primary text-text-primary dark:text-dark-text-primary"
                        >
                            {Object.values(Status).map(s => <option key={s} value={s}>{s}</option>)}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="assignee-input" className="block text-xs text-text-secondary dark:text-dark-text-secondary mb-1">Ответственный</label>
                        <input 
                            id="assignee-input"
                            type="text"
                            value={anomaly.assignee || ''}
                            onChange={(e) => handleAssigneeChange(e.target.value)}
                            placeholder="Не назначен"
                            className="w-full p-2 bg-surface dark:bg-dark-surface border border-border dark:border-dark-border rounded-md shadow-sm focus:ring-primary dark:focus:ring-dark-primary focus:border-primary dark:focus:border-dark-primary text-text-primary dark:text-dark-text-primary"
                        />
                    </div>
                        <div>
                        <label className="block text-xs text-text-secondary dark:text-dark-text-secondary mb-1">Связанные документы</label>
                        <p className="font-mono text-xs text-primary dark:text-dark-primary">{anomaly.relatedDocs.join(', ')}</p>
                    </div>
                </div>
                    <button onClick={handleSaveAndReturn} disabled={isSaving} className="mt-6 w-full bg-primary dark:bg-dark-primary text-white font-bold py-2 px-4 rounded-lg hover:bg-primary-hover dark:hover:bg-dark-primary-hover transition-colors disabled:bg-gray-400">
                     {isSaving ? 'Сохранение...' : 'Сохранить и вернуться'}
                </button>
            </Card>
        </div>
    );
};


const AnomaliesView: React.FC = () => {
  const [anomalies, setAnomalies] = useState<Anomaly[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedAnomaly, setSelectedAnomaly] = useState<Anomaly | null>(null);
  const [filters, setFilters] = useState<{ severity: string; status: string; search: string }>({ severity: 'All', status: 'All', search: '' });

  const fetchAnomalies = useCallback(async () => {
      try {
          setLoading(true);
          setError(null);
          const data = await getAnomalies(filters);
          setAnomalies(data);
      } catch (err) {
          setError("Не удалось загрузить список аномалий.");
          console.error(err);
      } finally {
          setLoading(false);
      }
  }, [filters]);

  useEffect(() => {
    fetchAnomalies();
  }, [fetchAnomalies]);
  
  const handleBackFromDetail = () => {
    setSelectedAnomaly(null);
    fetchAnomalies(); // Re-fetch list to see updated data
  };

  const handleSaveAnomaly = async (updatedAnomaly: Anomaly) => {
    await updateAnomaly(updatedAnomaly.id, updatedAnomaly);
    // The list will be re-fetched when we return
  };

  const exportToCSV = () => {
    const headers = ["ID", "Дата", "Критичность", "Категория", "Описание", "Статус", "Связанные документы", "Ответственный"];
    const csvRows = [
      headers.join(','),
      ...anomalies.map(row => {
        const values = [
          row.id,
          row.date,
          row.severity,
          row.category,
          `"${row.description.replace(/"/g, '""')}"`, // Escape quotes
          row.status,
          `"${row.relatedDocs.join('; ')}"`,
          row.assignee || "N/A"
        ];
        return values.join(',');
      })
    ];

    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', `anomalies_export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (selectedAnomaly) {
    return <AnomalyDetail anomaly={selectedAnomaly} onBack={handleBackFromDetail} onSave={handleSaveAnomaly} />;
  }

  const FilterSelect: React.FC<{label: string, id: string, value: string, onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void, options: string[]}> = ({label, id, value, onChange, options}) => (
      <div>
        <label htmlFor={id} className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary mb-1">{label}</label>
        <select id={id} value={value} onChange={onChange} className="bg-surface dark:bg-dark-surface border border-border dark:border-dark-border text-text-primary dark:text-dark-text-primary text-sm rounded-lg focus:ring-primary dark:focus:ring-dark-primary focus:border-primary dark:focus:border-dark-primary block w-full p-2.5">
            <option value="All">Все</option>
            {options.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>
  );

  return (
    <div className="space-y-6">
        <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-text-primary dark:text-dark-text-primary">Список аномалий ({loading ? '...' : anomalies.length})</h1>
            <button
                onClick={exportToCSV}
                className="bg-primary dark:bg-dark-primary text-white font-bold py-2 px-4 rounded-lg hover:bg-primary-hover dark:hover:bg-dark-primary-hover transition-colors text-sm"
            >
                Экспорт в CSV
            </button>
        </div>
        <Card>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div className="md:col-span-2">
                     <label htmlFor="search-filter" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary mb-1">Поиск</label>
                     <input 
                        id="search-filter"
                        type="text" 
                        placeholder="Поиск по ID или описанию..." 
                        value={filters.search}
                        onChange={(e) => setFilters(f => ({...f, search: e.target.value}))}
                        className="bg-surface dark:bg-dark-surface border border-border dark:border-dark-border text-text-primary dark:text-dark-text-primary text-sm rounded-lg focus:ring-primary dark:focus:ring-dark-primary focus:border-primary dark:focus:border-dark-primary block w-full p-2.5"
                     />
                </div>
                <FilterSelect label="Критичность" id="severity-filter" value={filters.severity} onChange={(e) => setFilters(f => ({...f, severity: e.target.value}))} options={Object.values(Severity)} />
                <FilterSelect label="Статус" id="status-filter" value={filters.status} onChange={(e) => setFilters(f => ({...f, status: e.target.value}))} options={Object.values(Status)} />
            </div>
            
            {loading ? (
                <div className="flex justify-center items-center h-64"><Spinner size="h-16 w-16" /></div>
            ) : error ? (
                <div className="text-center text-critical p-4 bg-red-100 rounded-lg col-span-full">{error}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-gray-50 dark:bg-dark-surface/50">
                    <tr className="border-b border-border dark:border-dark-border">
                      <th className="p-3 font-semibold text-sm text-text-secondary dark:text-dark-text-secondary">ID</th>
                      <th className="p-3 font-semibold text-sm text-text-secondary dark:text-dark-text-secondary">Категория</th>
                      <th className="p-3 font-semibold text-sm text-text-secondary dark:text-dark-text-secondary">Критичность</th>
                      <th className="p-3 font-semibold text-sm text-text-secondary dark:text-dark-text-secondary">Статус</th>
                      <th className="p-3 font-semibold text-sm text-text-secondary dark:text-dark-text-secondary">Дата</th>
                      <th className="p-3 font-semibold text-sm text-text-secondary dark:text-dark-text-secondary">Ответственный</th>
                    </tr>
                  </thead>
                  <tbody>
                    {anomalies.map((anomaly) => (
                      <tr key={anomaly.id} onClick={() => setSelectedAnomaly(anomaly)} className="border-b border-gray-200 dark:border-dark-border hover:bg-gray-50 dark:hover:bg-dark-surface/50 cursor-pointer">
                        <td className="p-4 font-mono text-sm text-primary dark:text-dark-primary font-medium">{anomaly.id}</td>
                        <td className="p-4 text-sm text-text-primary dark:text-dark-text-primary">{anomaly.category}</td>
                        <td className="p-4"><Badge type={anomaly.severity} /></td>
                        <td className="p-4"><Badge type={anomaly.status} /></td>
                        <td className="p-4 text-sm text-text-secondary dark:text-dark-text-secondary">{new Date(anomaly.date).toLocaleDateString('ru-RU')}</td>
                         <td className="p-4 text-sm text-text-secondary dark:text-dark-text-secondary">
                          <div className="flex items-center">
                            {anomaly.assignee ? (
                              <>
                                <UserCircleIcon className="w-5 h-5 mr-2 text-gray-400" />
                                {anomaly.assignee}
                              </>
                            ) : (
                              <span className="text-gray-400 italic">Не назначен</span>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
        </Card>
    </div>
  );
};

export default AnomaliesView;