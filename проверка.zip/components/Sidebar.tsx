import React from 'react';
import { View } from '../types';
import { DashboardIcon, AlertIcon, ShieldCheckIcon, SettingsIcon, RulesIcon } from './ui/icons';

interface SidebarProps {
  currentView: View;
  setCurrentView: (view: View) => void;
}

const NavItem: React.FC<{
  icon: React.ReactElement<{ className?: string }>;
  label: string;
  isActive: boolean;
  onClick: () => void;
}> = ({ icon, label, isActive, onClick }) => {
  return (
    <li
      onClick={onClick}
      className={`flex items-center p-3 my-1 rounded-lg cursor-pointer transition-colors duration-200 group ${
        isActive
          ? 'bg-primary-light text-primary dark:bg-dark-primary-light dark:text-dark-primary font-semibold'
          : 'text-text-secondary dark:text-dark-text-secondary hover:bg-gray-100 dark:hover:bg-dark-surface hover:text-text-primary dark:hover:text-dark-text-primary'
      }`}
    >
      {React.cloneElement(icon, {
          className: `w-6 h-6 transition-colors duration-200 ${isActive ? 'text-primary dark:text-dark-primary' : 'text-gray-400 dark:text-gray-500 group-hover:text-text-primary dark:group-hover:text-dark-text-primary'}`
      })}
      <span className="ml-3">{label}</span>
    </li>
  );
};

const Sidebar: React.FC<SidebarProps> = ({ currentView, setCurrentView }) => {
  const navItems = [
    {
      view: View.Dashboard,
      label: 'Панель управления',
      icon: <DashboardIcon />,
    },
    {
      view: View.Anomalies,
      label: 'Аномалии',
      icon: <AlertIcon />,
    },
    {
      view: View.Rules,
      label: 'Правила и Контроль',
      icon: <RulesIcon />,
    },
    {
      view: View.Settings,
      label: 'Настройки',
      icon: <SettingsIcon />,
    },
  ];

  return (
    <div className="w-64 bg-surface dark:bg-dark-surface flex-shrink-0 p-4 border-r border-border dark:border-dark-border flex flex-col">
      <div className="flex items-center mb-8 px-2 pt-2">
        <ShieldCheckIcon className="w-8 h-8 text-primary dark:text-dark-primary" />
        <h1 className="text-xl font-bold ml-2 text-text-primary dark:text-dark-text-primary tracking-tighter">Anomalia Guard</h1>
      </div>
      <nav className="flex-1">
        <ul>
          {navItems.map((item) => (
            <NavItem
              key={item.view}
              icon={item.icon}
              label={item.label}
              isActive={currentView === item.view}
              onClick={() => setCurrentView(item.view)}
            />
          ))}
        </ul>
      </nav>
      <div className="mt-auto p-4 bg-gray-50 dark:bg-dark-background rounded-lg text-center">
         <p className="text-xs text-text-secondary dark:text-dark-text-secondary">© 2024 Anomalia Guard. <br/> Все права защищены.</p>
      </div>
    </div>
  );
};

export default Sidebar;