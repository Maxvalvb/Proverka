import React, { useState, useRef, useEffect } from 'react';
import { SunIcon, MoonIcon, UserCircleIcon, BellIcon, LogoutIcon } from './ui/icons';
import { User } from '../types';

interface HeaderProps {
    user: User;
    theme: 'light' | 'dark';
    toggleTheme: () => void;
    onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, theme, toggleTheme, onLogout }) => {
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setIsProfileOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <header className="flex-shrink-0 bg-surface dark:bg-dark-surface h-16 flex items-center justify-end px-8 border-b border-border dark:border-dark-border">
      <div className="flex items-center space-x-5">
        <button
            onClick={toggleTheme}
            className="p-2 rounded-full text-text-secondary dark:text-dark-text-secondary hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
            aria-label="Toggle theme"
        >
            {theme === 'light' ? <MoonIcon className="w-6 h-6" /> : <SunIcon className="w-6 h-6" />}
        </button>

        <button className="p-2 rounded-full text-text-secondary dark:text-dark-text-secondary hover:bg-gray-100 dark:hover:bg-gray-700 relative" aria-label="Notifications">
            <BellIcon className="w-6 h-6" />
            <span className="absolute top-2 right-2 block h-2 w-2 rounded-full bg-primary ring-2 ring-surface dark:ring-dark-surface"></span>
        </button>

        <div className="relative" ref={profileRef}>
          <button onClick={() => setIsProfileOpen(!isProfileOpen)} className="flex items-center">
            <div className="text-right mr-4 hidden sm:block">
              <p className="text-sm font-medium text-text-primary dark:text-dark-text-primary">{user.name}</p>
              <p className="text-xs text-text-secondary dark:text-dark-text-secondary">{user.role}</p>
            </div>
            <img
              className="h-10 w-10 rounded-full object-cover ring-2 ring-offset-2 ring-offset-surface dark:ring-offset-dark-surface ring-primary dark:ring-dark-primary"
              src={`https://i.pravatar.cc/100?u=${user.email}`}
              alt="User avatar"
            />
          </button>

           {isProfileOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-surface dark:bg-dark-surface rounded-md shadow-lg py-1 ring-1 ring-border dark:ring-dark-border z-10">
                <div className="px-4 py-2 border-b border-border dark:border-dark-border">
                   <p className="text-sm font-medium text-text-primary dark:text-dark-text-primary truncate">{user.name}</p>
                   <p className="text-xs text-text-secondary dark:text-dark-text-secondary truncate">{user.email}</p>
                </div>
                <a
                  href="#"
                  onClick={(e) => { e.preventDefault(); onLogout(); }}
                  className="flex items-center px-4 py-2 text-sm text-text-secondary dark:text-dark-text-secondary hover:bg-gray-100 dark:hover:bg-gray-700"
                >
                  <LogoutIcon className="w-4 h-4 mr-3" />
                  Выйти
                </a>
              </div>
            )}
        </div>
      </div>
    </header>
  );
};

export default Header;