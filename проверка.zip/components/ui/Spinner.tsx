import React from 'react';

const Spinner: React.FC<{ size?: string; color?: string }> = ({ size = 'h-8 w-8', color = 'border-primary' }) => {
  return (
    <div className={`animate-spin rounded-full ${size} border-b-2 ${color}`}></div>
  );
};

export default Spinner;