import React from 'react';
import { Severity, Status } from '../../types';

interface BadgeProps {
  type: Severity | Status;
}

const getBadgeStyles = (type: Severity | Status) => {
  switch (type) {
    case Severity.Critical:
      return 'bg-red-100 dark:bg-red-900/40 text-red-700 dark:text-red-300 ring-1 ring-inset ring-red-200 dark:ring-red-500/30';
    case Severity.High:
      return 'bg-orange-100 dark:bg-orange-900/40 text-orange-700 dark:text-orange-300 ring-1 ring-inset ring-orange-200 dark:ring-orange-500/30';
    case Severity.Medium:
      return 'bg-yellow-100 dark:bg-yellow-900/40 text-yellow-800 dark:text-yellow-300 ring-1 ring-inset ring-yellow-200 dark:ring-yellow-500/30';
    case Severity.Low:
      return 'bg-green-100 dark:bg-green-900/40 text-green-700 dark:text-green-300 ring-1 ring-inset ring-green-200 dark:ring-green-500/30';
    case Status.New:
      return 'bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 ring-1 ring-inset ring-blue-200 dark:ring-blue-500/30';
    case Status.Review:
      return 'bg-purple-100 dark:bg-purple-900/40 text-purple-700 dark:text-purple-300 ring-1 ring-inset ring-purple-200 dark:ring-purple-500/30';
    case Status.Resolved:
      return 'bg-gray-200 dark:bg-gray-700/60 text-gray-700 dark:text-gray-300 ring-1 ring-inset ring-gray-300 dark:ring-gray-500/30';
    case Status.FalsePositive:
      return 'bg-gray-200 dark:bg-gray-700/60 text-gray-700 dark:text-gray-300 ring-1 ring-inset ring-gray-300 dark:ring-gray-500/30';
    default:
      return 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 ring-1 ring-inset ring-gray-200 dark:ring-gray-500/30';
  }
};

const Badge: React.FC<BadgeProps> = ({ type }) => {
  return (
    <span
      className={`px-2.5 py-0.5 text-xs font-medium rounded-full inline-block ${getBadgeStyles(type)}`}
    >
      {type}
    </span>
  );
};

export default Badge;
