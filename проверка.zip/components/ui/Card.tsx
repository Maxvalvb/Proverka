import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
}

const Card: React.FC<CardProps> = ({ children, className = '' }) => {
  return (
    <div className={`bg-surface dark:bg-dark-surface rounded-xl border border-border dark:border-dark-border shadow-sm p-6 ${className}`}>
      {children}
    </div>
  );
};

export default Card;
