import React, { useState } from 'react';
import { ShieldCheckIcon } from './ui/icons';
import { login } from '../services/apiService';
import { User } from '../types';
import Spinner from './ui/Spinner';

interface LoginViewProps {
  onLogin: (user: User, token: string) => void;
}

const LoginView: React.FC<LoginViewProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('auditor@example.com');
  const [password, setPassword] = useState('password');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Пожалуйста, введите email и пароль.');
      return;
    }
    
    setLoading(true);
    setError('');

    try {
      const { user, token } = await login(email, password);
      onLogin(user, token);
    } catch (err: any) {
      setError(err.message || 'Неверные учетные данные. Попробуйте еще раз.');
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-background dark:bg-dark-background px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
            <ShieldCheckIcon className="w-12 h-12 text-primary dark:text-dark-primary mx-auto" />
            <h1 className="text-3xl font-bold mt-2 text-text-primary dark:text-dark-text-primary tracking-tighter">Anomalia Guard</h1>
            <p className="text-text-secondary dark:text-dark-text-secondary mt-1">Войдите, чтобы продолжить</p>
        </div>
        
        <div className="bg-surface dark:bg-dark-surface p-8 rounded-xl border border-border dark:border-dark-border shadow-lg">
            <form onSubmit={handleLogin} className="space-y-6">
                <div>
                    <label htmlFor="email" className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">
                        Email
                    </label>
                    <div className="mt-1">
                        <input
                            id="email"
                            name="email"
                            type="email"
                            autoComplete="email"
                            required
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="block w-full px-3 py-2 bg-background dark:bg-dark-background border border-border dark:border-dark-border rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm text-text-primary dark:text-dark-text-primary"
                        />
                    </div>
                </div>

                <div>
                    <label htmlFor="password"className="block text-sm font-medium text-text-secondary dark:text-dark-text-secondary">
                        Пароль
                    </label>
                    <div className="mt-1">
                        <input
                            id="password"
                            name="password"
                            type="password"
                            autoComplete="current-password"
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="block w-full px-3 py-2 bg-background dark:bg-dark-background border border-border dark:border-dark-border rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary focus:border-primary sm:text-sm text-text-primary dark:text-dark-text-primary"
                        />
                    </div>
                </div>

                {error && <p className="text-sm text-critical text-center">{error}</p>}

                <div>
                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary hover:bg-primary-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-hover dark:bg-dark-primary dark:hover:bg-dark-primary-hover transition-colors disabled:bg-gray-400"
                    >
                        {loading ? <Spinner size="h-5 w-5" color="border-white" /> : 'Войти'}
                    </button>
                </div>
            </form>
        </div>
         <p className="text-center text-xs text-text-secondary dark:text-dark-text-secondary mt-8">
            © 2024 Anomalia Guard. Все права защищены.
         </p>
      </div>
    </div>
  );
};

export default LoginView;