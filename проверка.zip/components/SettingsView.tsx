import React, { useState } from 'react';
import Card from './ui/Card';
import ToggleSwitch from './ui/ToggleSwitch';
import { User } from '../types';

interface SettingsViewProps {
    user: User;
}

const SettingRow: React.FC<{ label: string; enabled: boolean; setEnabled: (enabled: boolean) => void }> = ({ label, enabled, setEnabled }) => {
    return (
        <div className="flex items-center justify-between">
            <span className="text-text-primary dark:text-dark-text-primary">{label}</span>
            <ToggleSwitch enabled={enabled} onChange={setEnabled} />
        </div>
    );
};

const SettingsView: React.FC<SettingsViewProps> = ({ user }) => {
    const [realtimeAnalysis, setRealtimeAnalysis] = useState(true);
    const [strictFraudDetection, setStrictFraudDetection] = useState(false);
    const [emailNotifications, setEmailNotifications] = useState(true);
    const [pushNotifications, setPushNotifications] = useState(false);

    return (
        <div className="space-y-8 max-w-4xl mx-auto">
            <div>
                <h1 className="text-3xl font-bold text-text-primary dark:text-dark-text-primary">Настройки</h1>
                <p className="mt-1 text-text-secondary dark:text-dark-text-secondary">Управляйте вашим профилем и настройками приложения.</p>
            </div>

            <Card>
                <h2 className="text-xl font-semibold border-b border-border dark:border-dark-border pb-4 mb-4 text-text-primary dark:text-dark-text-primary">Профиль</h2>
                <div className="flex items-center space-x-4">
                    <img
                        className="h-16 w-16 rounded-full object-cover ring-2 ring-offset-2 ring-offset-surface dark:ring-offset-dark-surface ring-primary dark:ring-dark-primary"
                        src={`https://i.pravatar.cc/100?u=${user.email}`}
                        alt="User avatar"
                    />
                    <div>
                        <h3 className="text-lg font-bold text-text-primary dark:text-dark-text-primary">{user.name}</h3>
                        <p className="text-sm text-text-secondary dark:text-dark-text-secondary">{user.role}</p>
                        <p className="text-sm text-text-secondary dark:text-dark-text-secondary">{user.email}</p>
                    </div>
                </div>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold border-b border-border dark:border-dark-border pb-4 mb-4 text-text-primary dark:text-dark-text-primary">Конфигурация анализа</h2>
                <div className="space-y-4">
                    <SettingRow label="Включить анализ в реальном времени" enabled={realtimeAnalysis} setEnabled={setRealtimeAnalysis} />
                    <SettingRow label="Более строгая проверка на мошенничество" enabled={strictFraudDetection} setEnabled={setStrictFraudDetection} />
                </div>
            </Card>

            <Card>
                <h2 className="text-xl font-semibold border-b border-border dark:border-dark-border pb-4 mb-4 text-text-primary dark:text-dark-text-primary">Уведомления</h2>
                <div className="space-y-4">
                    <SettingRow label="Email уведомления о критических аномалиях" enabled={emailNotifications} setEnabled={setEmailNotifications} />
                    <SettingRow label="Push-уведомления (требуется установка PWA)" enabled={pushNotifications} setEnabled={setPushNotifications} />
                </div>
            </Card>
        </div>
    );
};

export default SettingsView;