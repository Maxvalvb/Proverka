import { Anomaly, Severity, Status, Category, User } from '../types';
import { ruleCategories as defaultRuleCategories } from '../data/rules';

// --- MOCK DATABASE ---
let MOCK_ANOMALIES: Anomaly[] = [
  { id: 'ANOM-0001', date: '2024-07-20', severity: Severity.Critical, category: Category.Fraud, description: 'Крупный перевод на незарегистрированный счет', status: Status.New, relatedDocs: ['TR-12345'], assignee: 'Алексей Петров' },
  { id: 'ANOM-0002', date: '2024-07-19', severity: Severity.Medium, category: Category.Error, description: 'Дублирование счета-фактуры для поставщика', status: Status.Review, relatedDocs: ['INV-54321', 'INV-54322'], assignee: 'Мария Иванова' },
  { id: 'ANOM-0003', date: '2024-07-18', severity: Severity.High, category: Category.PolicyViolation, description: 'Оплата услуг по договору сверх лимита', status: Status.New, relatedDocs: ['CON-7890', 'PAY-11223'], assignee: 'Алексей Петров' },
  { id: 'ANOM-0004', date: '2024-07-18', severity: Severity.Low, category: Category.UnusualActivity, description: 'Платеж в нерабочее время (3:15 AM)', status: Status.Resolved, relatedDocs: ['PAY-11224'] },
  { id: 'ANOM-0005', date: '2024-07-17', severity: Severity.Medium, category: Category.Error, description: 'Неверный расчет НДС в накладной', status: Status.Review, relatedDocs: ['INV-54325'], assignee: 'Мария Иванова' },
  { id: 'ANOM-0006', date: '2024-07-16', severity: Severity.Critical, category: Category.Fraud, description: 'Создание фиктивного контрагента и оплата на его счет', status: Status.New, relatedDocs: ['VND-9988', 'PAY-11226'] },
  { id: 'ANOM-0007', date: '2024-07-15', severity: Severity.High, category: Category.Fraud, description: 'Изменение банковских реквизитов перед оплатой', status: Status.Review, relatedDocs: ['INV-54330', 'PAY-11227'], assignee: 'Алексей Петров' },
  { id: 'ANOM-0008', date: '2024-07-15', severity: Severity.Low, category: Category.Error, description: 'Опечатка в назначении платежа', status: Status.Resolved, relatedDocs: ['PAY-11228'] },
  { id: 'ANOM-0009', date: '2024-07-14', severity: Severity.Medium, category: Category.PolicyViolation, description: 'Закупка оборудования без утвержденной заявки', status: Status.New, relatedDocs: ['PO-6543'] },
  { id: 'ANOM-0010', date: '2024-07-12', severity: Severity.High, category: Category.UnusualActivity, description: 'Множественные мелкие переводы на один и тот же счет', status: Status.Review, relatedDocs: ['TR-12350', 'TR-12351', 'TR-12352'], assignee: 'Мария Иванова' },
  { id: 'ANOM-0011', date: '2024-07-11', severity: Severity.Medium, category: Category.Error, description: 'Оплата по уже оплаченному счету', status: Status.New, relatedDocs: ['INV-54300'] },
  { id: 'ANOM-0012', date: '2024-07-10', severity: Severity.Low, category: Category.UnusualActivity, description: 'Первый платеж новому контрагенту на крупную сумму', status: Status.Resolved, relatedDocs: ['VND-9989', 'PAY-11235'] },
  { id: 'ANOM-0013', date: '2024-07-09', severity: Severity.High, category: Category.PolicyViolation, description: 'Использование корпоративной карты в личных целях', status: Status.FalsePositive, relatedDocs: ['CC-TR-8877'] },
  { id: 'ANOM-0014', date: '2024-07-08', severity: Severity.Critical, category: Category.Fraud, description: 'Списание средств по поддельному акту выполненных работ', status: Status.New, relatedDocs: ['ACT-FAKE-01', 'PAY-11240'], assignee: 'Алексей Петров' },
  { id: 'ANOM-0015', date: '2024-07-07', severity: Severity.Medium, category: Category.UnusualActivity, description: 'Резкое увеличение расходов по статье "Представительские"', status: Status.Review, relatedDocs: ['GL-ACC-4500'], assignee: 'Мария Иванова' },
];

const getDefaultRuleState = (): Record<string, boolean> => {
    const defaultState: Record<string, boolean> = {};
    defaultRuleCategories.forEach(category => {
        category.rules.forEach(rule => {
            defaultState[rule.id] = rule.enabled;
        });
    });
    return defaultState;
};

// Use a simple object to simulate stored settings
let MOCK_RULE_SETTINGS: Record<string, boolean> = getDefaultRuleState();


// --- API SIMULATION ---
let authToken: string | null = null;
const API_DELAY = 500;

const simulateApiCall = <T>(data: T, requiresAuth = true, delay = API_DELAY): Promise<T> => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            if (requiresAuth && !authToken) {
                reject(new Error("401 Unauthorized"));
            } else {
                resolve(JSON.parse(JSON.stringify(data))); // Deep copy to prevent mutation issues
            }
        }, delay);
    });
};

// --- AUTH API ---
export const setAuthToken = (token: string | null) => {
    authToken = token;
};

export const login = (email: string, password: string): Promise<{ user: User, token: string }> => {
    console.log(`Simulating login for ${email}`);
    if (email === 'auditor@example.com' && password === 'password') {
        const token = `fake-jwt-token-for-${email}-${Date.now()}`;
        const user: User = {
            name: 'Алексей Петров',
            role: 'Финансовый аудитор',
            email: 'auditor@example.com',
        };
        return simulateApiCall({ user, token }, false);
    } else {
        return Promise.reject(new Error('Invalid credentials'));
    }
};

export const logout = () => {
    authToken = null;
    console.log("User logged out, token cleared.");
};

// --- DASHBOARD API ---
export const getDashboardData = async () => {
    const anomalies = MOCK_ANOMALIES;
    const stats = {
        totalAnomalies: anomalies.length,
        criticalCount: anomalies.filter(a => a.severity === Severity.Critical).length,
        highRiskCount: anomalies.filter(a => a.severity === Severity.High).length,
        inReviewCount: anomalies.filter(a => a.status === Status.Review).length,
    };
    
    const anomaliesByCategory = anomalies.reduce((acc, anom) => {
        acc[anom.category] = (acc[anom.category] || 0) + 1;
        return acc;
    }, {} as Record<Category, number>);
    const categoryData = Object.entries(anomaliesByCategory).map(([name, value]) => ({ name, value }));

    const anomaliesBySeverity = anomalies.reduce((acc, anom) => {
        acc[anom.severity] = (acc[anom.severity] || 0) + 1;
        return acc;
    }, {} as Record<Severity, number>);
    const severityData = Object.values(Severity).map(s => ({ name: s, value: anomaliesBySeverity[s] || 0 }));
    
    const recentHighRiskAnomalies = anomalies
        .filter(a => a.severity === Severity.Critical || a.severity === Severity.High)
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
        .slice(0, 5);

    return simulateApiCall({ stats, chartData: { categoryData, severityData }, recentHighRiskAnomalies });
};


// --- ANOMALIES API ---
export const getAnomalies = async (filters: { severity: string; status: string; search: string }): Promise<Anomaly[]> => {
    const filtered = MOCK_ANOMALIES.filter(anomaly => {
        const severityMatch = filters.severity === 'All' || anomaly.severity === filters.severity;
        const statusMatch = filters.status === 'All' || anomaly.status === filters.status;
        const searchMatch = filters.search === '' || 
                            anomaly.id.toLowerCase().includes(filters.search.toLowerCase()) || 
                            anomaly.description.toLowerCase().includes(filters.search.toLowerCase());
        return severityMatch && statusMatch && searchMatch;
    });
    return simulateApiCall(filtered);
};

export const updateAnomaly = async (anomalyId: string, updates: Partial<Anomaly>): Promise<Anomaly> => {
    const anomalyIndex = MOCK_ANOMALIES.findIndex(a => a.id === anomalyId);
    if (anomalyIndex === -1) {
        return Promise.reject(new Error("Anomaly not found"));
    }
    MOCK_ANOMALIES[anomalyIndex] = { ...MOCK_ANOMALIES[anomalyIndex], ...updates };
    return simulateApiCall(MOCK_ANOMALIES[anomalyIndex]);
};

// --- RULES API ---
export const getRuleSettings = async (): Promise<Record<string, boolean>> => {
    return simulateApiCall(MOCK_RULE_SETTINGS);
};

export const saveRuleSettings = async (settings: Record<string, boolean>): Promise<void> => {
    MOCK_RULE_SETTINGS = settings;
    console.log("Rule settings saved:", MOCK_RULE_SETTINGS);
    return simulateApiCall(undefined);
};

export const resetRuleSettings = async (): Promise<Record<string, boolean>> => {
    MOCK_RULE_SETTINGS = getDefaultRuleState();
    console.log("Rule settings reset to default.");
    return simulateApiCall(MOCK_RULE_SETTINGS);
};